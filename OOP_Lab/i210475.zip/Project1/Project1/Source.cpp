#include <iostream>
#include "Header.h"

using namespace std;

int main() {



	//cout<<**(Min_Max_Scaling(0, 1));

	return 0;
}