#include "pch.h"
#include "../Project1/Header.h"

int*** p;
threeD_array(p, 5, 4, 4);

////Task 1 TestCases
//char** ptr = words_to_sentence(3, 5);
//TEST(Task1, Test1) {
//
//	EXPECT_EQ('H', ptr[0][0]);
//	EXPECT_EQ('e', ptr[0][1]);
//	EXPECT_EQ('l', ptr[0][2]);
//	EXPECT_EQ('l', ptr[0][3]);
//	EXPECT_EQ('o', ptr[0][4]);
//}
//TEST(Task1, Test2) {
//	EXPECT_EQ('w', ptr[1][0]);
//	EXPECT_EQ('o', ptr[1][1]);
//	EXPECT_EQ('r', ptr[1][2]);
//	EXPECT_EQ('l', ptr[1][3]);
//	EXPECT_EQ('d', ptr[1][4]);
//}
//TEST(Task1, Test3) {
//	EXPECT_EQ('h', ptr[2][0]);
//	EXPECT_EQ('o', ptr[2][1]);
//	EXPECT_EQ('w', ptr[2][2]);
//}
//
//
//
//
////Task 2 TestCases
//int** ptr4 = Min_Max_Scaling(5, 6);
//TEST(Task2, Test1) {
//	EXPECT_EQ(80, ptr4[0][0]);
//	EXPECT_EQ(77, ptr4[0][1]);
//	EXPECT_EQ(78, ptr4[0][2]);
//	EXPECT_EQ(77, ptr4[0][3]);
//	EXPECT_EQ(79, ptr4[0][4]);
//	EXPECT_EQ(78, ptr4[0][5]);
//}
//TEST(Task2, Test2) {
//	EXPECT_EQ(52, ptr4[1][0]);
//	EXPECT_EQ(55, ptr4[1][1]);
//	EXPECT_EQ(50, ptr4[1][2]);
//	EXPECT_EQ(61, ptr4[1][3]);
//	EXPECT_EQ(58, ptr4[1][4]);
//	EXPECT_EQ(58, ptr4[1][5]);
//}
//TEST(Task2, Test3) {
//	EXPECT_EQ(77, ptr4[2][0]);
//	EXPECT_EQ(67, ptr4[2][1]);
//	EXPECT_EQ(74, ptr4[2][2]);
//	EXPECT_EQ(67, ptr4[2][3]);
//	EXPECT_EQ(67, ptr4[2][4]);
//	EXPECT_EQ(80, ptr4[2][5]);
//}
