#include <iostream>
#include "min max finder.h"
#include "string swap.h"
#include "task3 and 4.h"

using namespace std;

int main() {
    
    /*int const s = 15;
    int a[s],lgst,smst;

    for (int i = 0; i < s; i++) {

        cout << "Enter value of " << i+1 << " Element: ";
        cin >> a[i];


    }

    lgst= bara(a,s);
    smst = chota(a, s);

    cout << "Largest Number is: " << lgst;
    cout << "\nLargest Number is: " << smst;*/

    /////////////////////////////////////////////////////////////////////////////////////////////// TASK 2
    /*int i;
    char stra[3] = {'o','n', 'e', }, strb[3]= { 't','w', 'o', };
   
    cout << "Before Swap: ";

    for (i = 0; i<3 ; i++) {

        
    cout << stra[i] ;

    }
    cout << "   ";
    for (i = 0; i < 3; i++) {


        cout <<  strb[i];

    }

    swp( stra, strb);

    cout << "\nAfter Swap: " ;

    for (i = 0; i < 3; i++) {


        cout << stra[i];

    }
    cout << "   ";
    for (i = 0; i < 3; i++) {


        cout << strb[i];

    }*/

    ///////////////////////////////////////////////////////////////TASK 3

    /*int const limit=999;
    char in[limit], search;

    cout << "Enter a String: ";
    cin >> in;
    cout << "Enter a Character to search for: ";
    cin >> search;

    det(in,search);*/


    ///////////////////////////////////////////////////////////////TASK 4


    /*int a[6], b[6], c[6], d[6], e[6];

    int* array[5];
    
    *(array + 0) = a;
    *(array + 1) = b;
    *(array + 2) = c;
    *(array + 3) = d;
    *(array + 4) = e;

    ptrarray(array);*/
    
    
    return 0;
}
